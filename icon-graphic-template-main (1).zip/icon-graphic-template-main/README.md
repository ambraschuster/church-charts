# Icon graphic Template

## Students may use this template for their icon graphics assignment.